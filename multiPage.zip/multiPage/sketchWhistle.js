function setup() {
  let canvas = createCanvas(500, 400);
  canvas.parent("canvasContainer");
  background(220);
}

function draw() {

  circle(0, 0, 60)
  //
}


function mousePressed(){
  document.location.href = "index.html";
}